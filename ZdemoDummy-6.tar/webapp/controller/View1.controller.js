sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/ui/table/TablePersoController",
	"jerry/ZdemoDummy/util/formatter",
	"sap/m/MessageBox",
	'sap/ui/model/json/JSONModel',
	'sap/ui/model/Sorter',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library"
], function (Controller, Export, ExportTypeCSV, TablePersoController, formatter, MessageBox, JSONModel, Sorter, Filter, FilterOperator,
	Spreadsheet, exportLibrary) {
	"use strict";

	return Controller.extend("jerry.ZdemoDummy.controller.View1", {
		formatter: formatter,
		onInit: function () {
			var oModel = [];
			var oModel1 = new JSONModel(oModel);
			this.getView().setModel(oModel1, "myModel");

			this.eventTable = this.getView().byId("idEventTable");
			Controller = this;
			var oEditDataModel = new JSONModel();
			this.getView().setModel(oEditDataModel, "EditDataModel");
			var projModel = new JSONModel();
			projModel.setData([]);

			this.getView().setModel(projModel, "projModel");

			var auditLogModel = new JSONModel();
			this.getView().setModel(auditLogModel, "auditLog");
			this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			//Download
			var downloadModel = new JSONModel();
			this.getView().setModel(downloadModel, "DownloadMRef");
			this.DownloadMRef = this.getView().getModel("DownloadMRef");
			this.DownloadMRef.setSizeLimit(50000);
		},
		onAfterRendering: function () {
			//Controller.loadPersonalizationService();
			var oEditModel = this.getView().getModel("EditDataModel");
			var oEditData = oEditModel.getData();
			oEditData.isFieldsEditable = false;
			oEditModel.refresh(true);
			this.getTableData();
		},

		getTableData: function () {
			var that = this;
			sap.ui.core.BusyIndicator.show();
			this.oModel = this.getOwnerComponent().getModel();
			var oSorter = new Sorter({
				path: "EventId",
				descending: true
			});
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd/MM/YYYY"
			});
			this.oModel.read("/ZCVRCI_NPI_EVENTS_HDR", {
				urlParameters: {
					"$expand": "to_evt_prj,to_evt_cntry,to_evt_pval,to_evt_pexcl",
					"$orderby": "EventId desc"
				},
				sorters: oSorter,
				success: function (data, response) {
					sap.ui.core.BusyIndicator.hide();
					var planningData = data.results;
					that.getView().byId("totalRecords").setText("Total Records : " + data.results.length);
					for (var i = 0; i < planningData.length; i++) {
						planningData[i].newIdl = planningData[i].Idl === "X" ? true : false;
						planningData[i].newSts = planningData[i].Sts === "X" ? true : false;
						planningData[i].newNpi = planningData[i].Npi === "X" ? true : false;
						planningData[i].newIpk = planningData[i].Ipk === "X" ? true : false;
						planningData[i].newSfs = planningData[i].Sfs === "X" ? true : false;
						planningData[i].newTwe = planningData[i].Twe === "X" ? true : false;

						planningData[i].EmbargoDtFilter = dateFormat.format(planningData[i].EmbargoDt);
						planningData[i].LaunchDtFilter = dateFormat.format(planningData[i].LaunchDt);
						planningData[i].PreOrdDtLclFilter = dateFormat.format(planningData[i].PreOrdDtLcl);
						planningData[i].PreOrdDtPstFilter = dateFormat.format(planningData[i].PreOrdDtPst);
						planningData[i].SchDateFilter = dateFormat.format(planningData[i].SchDate);
						//dateStr = display

						var countryData = planningData[i].to_evt_cntry.results;
						var j;
						planningData[i].Country = [];
						for (j = 0; j < countryData.length; j++) {
							planningData[i].Country.push(countryData[j].AttribValue);
						}
						planningData[i].CountryFilter = planningData[i].Country.join();

						var projectData = planningData[i].to_evt_prj.results;
						planningData[i].ProjectCode = "";
						for (j = 0; j < projectData.length; j++) {
							if (planningData[i].ProjectCode) {
								planningData[i].ProjectCode += "," + projectData[j].AttribValue;
							} else {
								planningData[i].ProjectCode = projectData[j].AttribValue;
							}
						}

						var excludeData = planningData[i].to_evt_pexcl.results;
						planningData[i].pexcl = "";
						for (j = 0; j < excludeData.length; j++) {
							if (planningData[i].pexcl) {
								planningData[i].pexcl += "," + excludeData[j].AttribValue;
							} else {
								planningData[i].pexcl = excludeData[j].AttribValue;
							}
						}
						var vaateData = planningData[i].to_evt_pval.results;
						planningData[i].pval = "";
						for (j = 0; j < vaateData.length; j++) {
							if (planningData[i].pval) {
								planningData[i].pval += "," + vaateData[j].AttribValue;
							} else {
								planningData[i].pval = vaateData[j].AttribValue;
							}
						}
					}
					
					var planningModel = new sap.ui.model.json.JSONModel();
					planningModel.setData(planningData);
					that.getView().setModel(planningModel, "eventModel");
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide(0);
				}
			});
		},

		handleDownload: function () {
			var that = this;
			var oTable = this.getView().byId("idEventTable");
			var eventData = oTable.getModel("eventModel").getData();
			eventData.forEach(function (i, v) {
				for (var property in i) {
					if (i[property] === "" || i[property] === null || (Array.isArray(i[property]) && i[property].length)) {
						i[property] = " ";
					}
					if (i[property].ms === 0) {
						i[property].ms = " ";
					}
				}
			});
			this.DownloadMRef.getData().mSettings = {
				fileName: "Event_Report",
				showProgress: false,
				workbook: {
					columns: [],
					context: {
						title: "Event_Report",
						sheetName: "Event_Report"
					}
				},
				dataSource: eventData
			};
			this.DownloadMRef.refresh();
			this.DownloadMRef.getData().mSettings.workbook.columns = this.getColumnConfigurations(oTable);
			this.DownloadMRef.refresh();
			sap.ui.core.BusyIndicator.show(0);
			var oSheet = new Spreadsheet(this.DownloadMRef.getData().mSettings);
			oSheet.build().then(function () {
					sap.ui.core.BusyIndicator.hide();
				})
				.finally(function () {
					sap.ui.core.BusyIndicator.hide();
					oSheet.destroy();
					that.DownloadMRef.getData().mSettings = {};
					that.DownloadMRef.refresh();
				});
		},

		// getColumnConfigurations: function (oTable) {
		// 	var columnHeaderData = oTable.getColumns();
		// 	var columns = [];
		// 	var EdmType = exportLibrary.EdmType;
		// 	var fname;
		// 	for (var i = 0; i < columnHeaderData.length; i++) {

		// 		if (columnHeaderData[i].getAggregation("template")) {
		// 			var template = columnHeaderData[i].getAggregation("template");
		// 			if (template.getBindingInfo("text"))
		// 				fname = template.getBindingInfo("text").parts[0].path;
		// 			if (template.getBindingInfo("value"))
		// 				fname = template.getBindingInfo("value").parts[0].path;
		// 			if (template.getBindingInfo("selected"))
		// 				fname = template.getBindingInfo("selected").parts[0].path;
		// 			if (template.getBindingInfo("selectedKey"))
		// 				fname = template.getBindingInfo("selectedKey").parts[0].path;
		// 		}

		// 		columns.push({
		// 			label: oTable._getVisibleColumns()[i].getAggregation("label").getProperty("text"),
		// 			property: fname,
		// 			type: "string"
		// 				// wrap: true
		// 		});

		// 		// if (fname === "EventId" || fname === "EventName" || fname === "ProjectCode" || fname === "CountryFilter" || fname ===
		// 		// 	"LaunchDtStr" ||
		// 		// 	fname === "PreOrdDtPstStr" || fname === "PreOrdTmPst" || fname === "PreOrdDtLcl" || fname === "PreOrdTmLcl" || fname ===
		// 		// 	"EmbargoDt" || fname === "Wave" || fname === "Lob" || fname === "Npi" || fname === "Ipk" || fname === "Twe" || fname === "Sfs" ||
		// 		// 	fname === "TwDays" || fname === "Sts" || fname === "Idl" || fname === "Status" || fname === "pexcl" || fname === "Schdate" ||
		// 		// 	fname === "Schtime" || fname === "pval" || fname === "Comments" || fname === "ValdResult" || fname === "ValdDt" || fname ===
		// 		// 	"ValdTm" || fname === "Country"
		// 		// ) {
		// 		// 	if (fname === "PreOrdTmPst" || fname === "PreOrdTmLcl" || fname === "ValdTm") {
		// 		// 		columns.push({
		// 		// 			label: this.i18n.getText(fname.toString()),
		// 		// 			property: fname,
		// 		// 			type: EdmType.Time
		// 		// 		});
		// 		// 	} else {
		// 		// 		columns.push({
		// 		// 			label: this.i18n.getText(fname.toString()),
		// 		// 			property: fname.toString()
		// 		// 		});
		// 		// 	}
		// 		// }
		// 	}
		// 	return columns;
		// },

		getColumnConfigurations: function (eventData) { //OLD
			var columnHeaderData = eventData[0];
			var columns = [];
			var EdmType = exportLibrary.EdmType;
			for (var fname in columnHeaderData) {
				if (fname === "EventId" || fname === "EventName" || fname === "ProjectCode" || fname === "CountryFilter" || fname ===
					"LaunchDtStr" ||
					fname === "PreOrdDtPstStr" || fname === "PreOrdTmPst" || fname === "PreOrdDtLcl" || fname === "PreOrdTmLcl" || fname ===
					"EmbargoDt" || fname === "Wave" || fname === "Lob" || fname === "Npi" || fname === "Ipk" || fname === "Twe" || fname === "Sfs" ||
					fname === "TwDays" || fname === "Sts" || fname === "Idl" || fname === "Status" || fname === "pexcl" || fname === "Schdate" ||
					fname === "Schtime" || fname === "pval" || fname === "Comments" || fname === "ValdResult" || fname === "ValdDt" || fname ===
					"ValdTm"
				) {
					if (fname === "PreOrdTmPst" || fname === "PreOrdTmLcl" || fname === "ValdTm") {
						columns.push({
							label: this.i18n.getText(fname.toString()),
							property: fname,
							type: EdmType.Time
						});
					} else {
						columns.push({
							label: this.i18n.getText(fname.toString()),
							property: fname.toString()
						});
					}
				}
			}
			return columns;
		},

		// handleDownload: function () {
		// 	var oTable = this.getView().byId("idEventTable");
		// 	var oModel = new sap.ui.model.json.JSONModel();
		// 	var filNam;
		// 	if (oTable.getModel("eventModel").getData().length <= 0) {
		// 		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
		// 		sap.m.MessageBox.warning("No Data to Download", {
		// 			styleClass: bCompact ? "sapUiSizeCompact" : ""
		// 		});
		// 		return;
		// 	} else {
		// 		filNam = "Event_Report";
		// 		oModel.setData(oTable.getModel("eventModel").getData());
		// 	}

		// 	if (oModel.getData() !== undefined && oModel.getData().length > 0) {
		// 		var oExport = new Export({
		// 			exportType: new ExportTypeCSV({
		// 				fileExtension: "csv",
		// 				separatorChar: ","
		// 			}),
		// 			models: oModel,
		// 			rows: {
		// 				path: "/"
		// 			},
		// 			columns: [{
		// 				name: "Event Id",
		// 				template: {
		// 					content: "{EventId}"
		// 				}
		// 			}, {
		// 				name: "Event Name",
		// 				template: {
		// 					content: "{EventName}"
		// 				}
		// 			}, {
		// 				name: "Project Code",
		// 				template: {
		// 					content: "{ProjectCode}"
		// 				}
		// 			}, {
		// 				name: "Country",
		// 				template: {
		// 					content: "{Country}"
		// 				}
		// 			}, {
		// 				name: "Launch Date",
		// 				template: {
		// 					content: "{LaunchDt}"
		// 				}
		// 			}, {
		// 				name: "PreOrder Date(Pst)",
		// 				template: {
		// 					content: "{path:'PreOrdDtPst', type:'sap.ui.model.type.Date',formatOptions: { style: 'short', strictParsing: true}}"
		// 				}
		// 			}, {
		// 				name: "Preorder Time(PST)",
		// 				template: {
		// 					content: "{path: 'PreOrdTmPst', type: 'sap.ui.model.odata.type.Time', formatOptions: { pattern : 'hh:mm:ss a' }}"
		// 				}
		// 			}, {
		// 				name: "Preorder Date(Local)",
		// 				template: {
		// 					content: "{path:'PreOrdDtLcl', type:'sap.ui.model.type.Date',formatOptions: { style: 'short', strictParsing: true}}"
		// 				}
		// 			}, {
		// 				name: "Preorder Time(Local)",
		// 				template: {
		// 					content: "{path: 'PreOrdTmLcl', type: 'sap.ui.model.odata.type.Time', formatOptions: { pattern : 'hh:mm:ss a' }}"
		// 				}
		// 			}, {
		// 				name: "Embargo Date(Local)",
		// 				template: {
		// 					content: "{path:'EmbargoDt', type:'sap.ui.model.type.Date',formatOptions: { style: 'short', strictParsing: true}}"
		// 				}
		// 			}, {
		// 				name: "Wave",
		// 				template: {
		// 					content: "{Wave}"
		// 				}
		// 			}, {
		// 				name: "LOB",
		// 				template: {
		// 					content: "{Lob}"
		// 				}
		// 			}, {
		// 				name: "NPI",
		// 				template: {
		// 					content: "{Npi}"
		// 				}
		// 			}, {
		// 				name: "IPK",
		// 				template: {
		// 					content: "{Ipk}"
		// 				}
		// 			}, {
		// 				name: "Twe",
		// 				template: {
		// 					content: "{Twe}"
		// 				}
		// 			}, {
		// 				name: "Sfs",
		// 				template: {
		// 					content: "{Sfs}"
		// 				}
		// 			}, {
		// 				name: "TW Days",
		// 				template: {
		// 					content: "{TwDays}"
		// 				}
		// 			}, {
		// 				name: "STS",
		// 				template: {
		// 					content: "{Sts}"
		// 				}
		// 			}, {
		// 				name: "Idl",
		// 				template: {
		// 					content: "{Idl}"
		// 				}
		// 			}, {
		// 				name: "Status",
		// 				template: {
		// 					content: {
		// 						parts: ["Status"],
		// 						formatter: formatter.statusFormatter
		// 					}
		// 				}

		// 			}, {
		// 				name: "Exclude parts",
		// 				template: {
		// 					content: "{pexcl}"
		// 				}
		// 			}, {
		// 				name: "Scheduled Date",
		// 				template: {
		// 					content: "{path:'Schdate', type:'sap.ui.model.type.Date',formatOptions: { style: 'short', strictParsing: true}}"
		// 				}
		// 			}, {
		// 				name: "Scheduled Time",
		// 				template: {
		// 					content: "{path: 'Schtime', type: 'sap.ui.model.odata.type.Time', formatOptions: { pattern : 'hh:mm:ss a' }}"
		// 				}
		// 			}, {
		// 				name: "Parts to be validated",
		// 				template: {
		// 					content: "{pval}"
		// 				}
		// 			}, {
		// 				name: "Comments",
		// 				template: {
		// 					content: "{Comments}"
		// 				}
		// 			}, {
		// 				name: "Validated Result",
		// 				template: {
		// 					content: "{ValdResult}"
		// 				}
		// 			}, {
		// 				name: "Validated Date",
		// 				template: {
		// 					content: "{path:'ValdDt', type:'sap.ui.model.type.Date',formatOptions: { style: 'short', strictParsing: true}}"
		// 				}
		// 			}, {
		// 				name: "Validated Time",
		// 				template: {
		// 					content: "{path: 'ValdTm', type: 'sap.ui.model.odata.type.Time', formatOptions: { pattern : 'hh:mm:ss a' }}"
		// 				}
		// 			}]
		// 		});
		// 		oExport.saveFile(filNam).catch(function (oError) {

		// 		}).then(function () {
		// 			oExport.destroy();
		// 		});
		// 	}
		// },

		//Function for Audit log	
		handleAuditLog: function () {
			var oTable = this.getView().byId("idEventTable");
			var selectedItems = oTable.getSelectedIndices();
			if (selectedItems.length > 0) {
				var aFilters = [];
				for (var i = 0; i < selectedItems.length; i++) {
					var selEventId = oTable.getModel("eventModel").getData()[selectedItems[i]].EventId;
					aFilters.push(new Filter("EventId", FilterOperator.EQ, selEventId));
				}
				//	var selEventId  = oTable.getModel("eventModel").getData()[selectedItems[0]].EventId;
				if (!this.auditLogDialog) {
					this.auditLogDialog = sap.ui.xmlfragment("auditLog", "com.apple.ui5.ZUI5_RDM_EVNTPL.view.fragments.auditLog", this);
					this.getView().addDependent(this.auditLogDialog);
				}
				var that = this;
				this.oModel.read("/AuditTrialSet", {
					urlParameters: {
						"$expand": "NavEvtToHdr",
						"$orderby": "EventId desc"
					},
					filters: aFilters,
					success: function (data, response) {
						var auditData = [];
						for (var j = 0; j < data.results.length; j++) {
							auditData = auditData.concat(data.results[j].NavEvtToHdr.results);
						}
						var auditLog = that.getView().getModel("auditLog");
						auditLog.setData(auditData);
						auditLog.refresh(true);
					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide(0);
					}
				});
				this.auditLogDialog.open();
			} else {
				MessageBox.alert("No record selected for Audit log");
			}

		},

		onAuditClose: function () {
			this.auditLogDialog.close();
		},

		onliveChangeSearch: function (oEvent) {
			try {
				var oTable, sQuery;
				oTable = this.getView().byId("idEventTable");
				var filters = [];
				sQuery = oEvent.getParameter("newValue");
				if (sQuery) {
					filters = new sap.ui.model.Filter([
							new sap.ui.model.Filter("ProjectCode", sap.ui.model.FilterOperator.Contains, sQuery),
							new sap.ui.model.Filter("CountryFilter", sap.ui.model.FilterOperator.Contains, sQuery),
							new sap.ui.model.Filter("EmbargoDtFilter", sap.ui.model.FilterOperator.Contains, sQuery),
							new sap.ui.model.Filter("LaunchDtFilter", sap.ui.model.FilterOperator.Contains, sQuery),
							new sap.ui.model.Filter("PreOrdDtLclFilter", sap.ui.model.FilterOperator.Contains, sQuery),
							new sap.ui.model.Filter("PreOrdDtPstFilter", sap.ui.model.FilterOperator.Contains, sQuery),
							new sap.ui.model.Filter("SchDateFilter", sap.ui.model.FilterOperator.Contains, sQuery)
						],
						false);
					oTable.getBinding("rows").filter(filters, sap.ui.model.FilterType.Application);
				} else {
					oTable.getBinding("rows").filter(filters, sap.ui.model.FilterType.Application);
				}
			} catch (oError) {}
		},

		handleAdvSearchExpand: function (oEvent) {
			var oPanel = this.getView().byId("f_form");
			if (oPanel.getVisible()) {
				oPanel.setVisible(false);
				oEvent.getSource().setIcon("sap-icon://navigation-down-arrow");
			} else {
				oPanel.setVisible(true);
				oEvent.getSource().setIcon("sap-icon://navigation-up-arrow");
			}
		},

		//Edit Table Row
		handleEdit: function (oEvent) {
			var oEditModel = this.getView().getModel("EditDataModel");
			var oEditData = oEditModel.getData();
			oEvent.getSource().setVisible(false);
			this.getView().byId("rowSave").setVisible(true);
			this.getView().byId("rowUpdate").setVisible(true);
			this.getView().byId("rowCancel").setVisible(true);
			oEditData.isFieldsEditable = true;
			oEditModel.refresh(true);
		},

		//Create new Row in a table 
		handleAddRow: function () {
			var oTableModel = this.getView().getModel("eventModel");
			var aData = oTableModel.getData();
			var object = {
				"EventId": "New",
				"EventName": "",
				"ProjectCode": "",
				"Country": [],
				"LaunchDt": "",
				"PreOrdDtPst": "",
				"PreOrdTmPst": "",
				"PreOrdDtLcl": "",
				"PreOrdTmLcl": "",
				"EmbargoDt": "",
				"Wave": "",
				"Lob": "",
				"Npi": false,
				"Ipk": false,
				"Twe": false,
				"Sfs": false,
				"TwDays": "",
				"Sts": false,
				"Idl": false,
				"Status": "",
				"pexcl": "",
				"Schdate": "",
				"Schtime": "",
				"pval": "",
				"Comments": "",
				"ValdResult": "",
				"ValdDt": "",
				"ValdTm": ""
			};
			aData.unshift(object);
			oTableModel.setData(aData);
			oTableModel.refresh(true);
		},
		onChangeEventDec: function (evt) {

			var bVal = false;
			
			var obj = evt.getSource().getParent().getBindingContext("eventModel").getObject().EventId;
			var key = evt.getParameters("newValue");
			var evtKey = evt.getSource().getParent().getBindingContext("eventModel").getObject().EventKey;
			var oModel = this.getView().getModel("myModel").getData();
			if (oModel.length > 0) {
				for (var i = 0; i < oModel.length; i++) {
					if (oModel[i].EventId === obj) {
						bVal = true;
						if (bVal === true) {
							var index = i;
						}
					} else {
						//	return;

					}
				}
				if (bVal === true) {
					oModel[index].EventName = key.newValue;
					oModel[index].EventKey = evtKey;
					index = 0;
				} else {

					oModel.push({

						
						"EventKey": evtKey,
						"EventId": obj, //selectedData.EventId,
						"EventName": key.newValue,
					

					});
					this.getView().getModel("myModel").refresh();
				}
			} else {

				oModel.push({

					
					"EventKey": evtKey,
					"EventId": obj, //selectedData.EventId,
					"EventName": key.newValue,
				

				});
				this.getView().getModel("myModel").refresh();

			}

		},
		changeLaunchDt: function (evt) {

		},
		onSelectLOB: function (evt) {
			var bVal = false;
			
			var obj = evt.getSource().getParent().getBindingContext("eventModel").getObject().EventId;
			var evtKey = evt.getSource().getParent().getBindingContext("eventModel").getObject().EventKey;
			var key = evt.getParameters().selectedItem.getProperty("key");
			var oModel = this.getView().getModel("myModel").getData();
			if (oModel.length > 0) {
				for (var i = 0; i < oModel.length; i++) {
					if (oModel[i].EventId === obj) {
						bVal = true;
						if (bVal === true) {
							var index = i;
						}
					} else {
						//	return;

					}
				}
				if (bVal === true) {
					oModel[index].Lob = key;
					oModel[index].EventKey = evtKey;
					index = 0;

				} else {

					oModel.push({

					
						"Lob": key,
						
						"EventKey": evtKey,
						"EventId": obj, //selectedData.EventId,
					

					});
					this.getView().getModel("myModel").refresh();
				}
			} else {

				oModel.push({

					
					"Lob": key,
				
					"EventKey": evtKey,
					"EventId": obj, //selectedData.EventId,
					

				});
				this.getView().getModel("myModel").refresh();

			}
		},
		handleSave: function (oEvent) {

			var oView = this.getView();
			var oModel = this.getOwnerComponent().getModel();
			oModel.setDeferredGroups(["createEventPlan"]);

			var oTable = this.getView().byId("idEventTable");
			var tableData = oTable.getModel("eventModel").getData();
			var that = this;
			var newRecordCount = 0;
			var obj;
			if (tableData.length > 0) {
				for (var i = 0; i < tableData.length; i++) {
					var eventId = tableData[i].EventId;
					if (eventId === "New") {
						newRecordCount++;
						var selectedData = tableData[i];
						var twDays = parseInt(selectedData.TwDays);
						var wave = selectedData.Wave; //parseInt(selectedData.Wave); //remove integer parsing
						var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "yyyy/MM/dd'T'HH:mm"
						});
						var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
							pattern: '\'PT\'hh\'H\'mm\'M\'ss\'S\''
						});
						var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
						var PreOrdTmPst, PreOrdTmLcl, SchTime;
						if (selectedData.PreOrdTmPst) {
							PreOrdTmPst = timeFormat.format(new Date(selectedData.PreOrdTmPst.ms + TZOffsetMs));
						} else {
							PreOrdTmPst = null;
						}
						if (selectedData.PreOrdTmLcl) {
							PreOrdTmLcl = timeFormat.format(new Date(selectedData.PreOrdTmLcl.ms + TZOffsetMs));
						} else {
							PreOrdTmLcl = null;
						}
						if (selectedData.SchTime) {
							SchTime = timeFormat.format(new Date(selectedData.SchTime.ms + TZOffsetMs));
						} else {
							SchTime = null;
						}

						var projCode = selectedData.ProjectCode.split(";");
						var projList = [];
						for (var p = 0; p < projCode.length; p++) {
							obj = {};
							obj.AttribKey = "";
							obj.ParentKey = "";
							obj.AttribId = "PC";
							obj.AttribValue = projCode[p];
							projList.push(obj);
						}

						var countryCode = selectedData.Country;
						var countryList = [];
						for (var c = 0; c < countryCode.length; c++) {
							obj = {};
							obj.AttribKey = "";
							obj.ParentKey = "";
							obj.AttribId = "CN";
							obj.AttribValue = countryCode[c];
							countryList.push(obj);
						}

						var excludeParts = selectedData.pexcl.split(";");
						var excludeList = [];
						for (var e = 0; e < excludeParts.length; e++) {
							obj = {};
							obj.AttribKey = "";
							obj.ParentKey = "";
							obj.AttribId = "EX";
							obj.AttribValue = excludeParts[e];
							excludeList.push(obj);
						}

						var validParts = selectedData.pval.split(";");
						var validList = [];
						for (var v = 0; v < validParts.length; v++) {
							obj = {};
							obj.AttribKey = "";
							obj.ParentKey = "";
							obj.AttribId = "PV";
							obj.AttribValue = validParts[e];
							validList.push(obj);
						}
						var obj = {
							"TwDays": twDays,
							"Idl": selectedData.Idl ? "X" : "",
							"Sts": selectedData.Sts ? "X" : "",
							"Npi": selectedData.Npi ? "X" : "",
							"Ipk": selectedData.Ipk ? "X" : "",
							"Twe": selectedData.Twe ? "X" : "",
							"Sfs": selectedData.Sfs ? "X" : "",
							"Wave": wave,
							"EmbargoDtTech": dateFormat.format(selectedData.EmbargoDt),
							"EmbargoDtStr": selectedData.EmbargoDt,
							"PreOrdDtPstTech": dateFormat.format(selectedData.PreOrdDtPst),
							"PreOrdDtPstStr": selectedData.PreOrdDtPst,
							"Lob": selectedData.Lob,
							"PreOrdTmPst": PreOrdTmPst,
							"PreOrdTmLcl": PreOrdTmLcl,
							"PreOrdDtLclTech": dateFormat.format(selectedData.PreOrdDtLcl), //yyyymmdd
							"PreOrdDtLclStr": selectedData.PreOrdDtLcl,
							"SchDateTech": dateFormat.format(selectedData.SchDate),
							"SchTime": SchTime,
							"Comments": selectedData.Comments,
							"Status": selectedData.Status,
							"ValdResult": selectedData.ValdResult,
							"ValdDt": null,
							"ValdTm": null,
							"CreatedBy": "",
							"CreatedDt": null,
							"CreatedTm": null,
							"ChangedBy": "",
							"ChangedDt": null,
							"ChangedTm": null,
							"EventKey": "",
							"EventId": "", //selectedData.EventId,
							"EventName": selectedData.EventName,
							"LaunchDtTech": dateFormat.format(selectedData.LaunchDt),
							"to_evt_prj": projList,
							"to_evt_cntry": countryList,
							"to_evt_pexcl": excludeList,
							"to_evt_pval": validList
						};

						oModel.create("/ZCVRCI_NPI_EVENTS_HDR", obj, {
							groupId: "createEventPlan"
						});

					}
				}
			}

			if (newRecordCount > 0) {
				var oBusyDialog = new sap.m.BusyDialog();
				oBusyDialog.open();
				oModel.submitChanges({
					groupId: "createEventPlan",
					success: function (odata, resp) {
					
						MessageBox.success("Rows added Successfully");
						that.getView().getModel("myModel").setData([]);
						that.getView().byId("idEventTable").clearSelection();
						var oEditModel = that.getView().getModel("EditDataModel");
						var oEditData = oEditModel.getData();
						that.getView().byId("rowSave").setVisible(false);
						that.getView().byId("rowCancel").setVisible(false);
						that.getView().byId("rowEdit").setVisible(true);
						oEditData.isFieldsEditable = false;
						oEditModel.refresh(true);
						that.getTableData();
						oBusyDialog.close();
					},
					error: function (odata, resp) {
						sap.m.MessageBox.error("Error Saving Entries!!");
						oBusyDialog.close();

					}

				});
			} else {
				MessageBox.alert("No new records added to Save");
			}

		},
		handleUpdate: function (oEvent) {
			var oView = this.getView();
			var oDataModel = this.getOwnerComponent().getModel();
			oDataModel.setDeferredGroups(["createEventPlan"]);
			var oModel = this.getView().getModel("myModel").getData();

			var that = this;

			//	var binaryValue = this.handleBinaryData(EventKey);

			for (var i = 0; i < oModel.length; i++) {
				var binaryValue = this.handleBinaryData(oModel[i].EventKey);
				oDataModel.update("/ZCVRCI_NPI_EVENTS_HDR(binary'" + binaryValue + "')", oModel[i], {
					groupId: "createEventPlan"
				});

			}

			if (oModel.length > 0) {
				var oBusyDialog = new sap.m.BusyDialog();
				oBusyDialog.open();
				oBusyDialog.close();
				oDataModel.submitChanges({
					groupId: "createEventPlan",
					success: function (odata, resp) {
					
						that.getView().getModel("myModel").setData([]);

						MessageBox.success("Rows added Successfully");
						that.getView().byId("idEventTable").clearSelection();
						var oEditModel = that.getView().getModel("EditDataModel");
						var oEditData = oEditModel.getData();
						that.getView().byId("rowSave").setVisible(false);
						that.getView().byId("rowCancel").setVisible(false);
						that.getView().byId("rowEdit").setVisible(true);
						oEditData.isFieldsEditable = false;
						oEditModel.refresh(true);
						that.getTableData();
						oBusyDialog.close();
					},
					error: function (odata, resp) {
						sap.m.MessageBox.error("Error Saving Entries!!");
						oBusyDialog.close();

					}

				});
			} else {
				MessageBox.alert("No new records added to Save");
			}

		},
		// handleSave: function (oEvent) {
		// 	var oTable = this.getView().byId("idEventTable");
		// 	var tableData = oTable.getModel("eventModel").getData();
		// 	var that = this;
		// 	var newRecordCount = 0;
		// 	var obj;
		// 	if (tableData.length > 0) {
		// 		for (var i = 0; i < tableData.length; i++) {
		// 			var eventId = tableData[i].EventId;
		// 			if (eventId === "New") {
		// 				newRecordCount++;
		// 				var selectedData = tableData[i];
		// 				var twDays = parseInt(selectedData.TwDays);
		// 				var wave = parseInt(selectedData.Wave);
		// 				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
		// 					pattern: "yyyy/MM/dd'T'HH:mm"
		// 				});
		// 				var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
		// 					pattern: '\'PT\'hh\'H\'mm\'M\'ss\'S\''
		// 				});
		// 				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
		// 				var PreOrdTmPst, PreOrdTmLcl, SchTime;
		// 				if (selectedData.PreOrdTmPst) {
		// 					PreOrdTmPst = timeFormat.format(new Date(selectedData.PreOrdTmPst.ms + TZOffsetMs));
		// 				} else {
		// 					PreOrdTmPst = null;
		// 				}
		// 				if (selectedData.PreOrdTmLcl) {
		// 					PreOrdTmLcl = timeFormat.format(new Date(selectedData.PreOrdTmLcl.ms + TZOffsetMs));
		// 				} else {
		// 					PreOrdTmLcl = null;
		// 				}
		// 				if (selectedData.SchTime) {
		// 					SchTime = timeFormat.format(new Date(selectedData.SchTime.ms + TZOffsetMs));
		// 				} else {
		// 					SchTime = null;
		// 				}

		// 				var projCode = selectedData.ProjectCode.split(";");
		// 				var projList = [];
		// 				for (var p = 0; p < projCode.length; p++) {
		// 					obj = {};
		// 					obj.AttribKey = "";
		// 					obj.ParentKey = "";
		// 					obj.AttribId = "PC";
		// 					obj.AttribValue = projCode[p];
		// 					projList.push(obj);
		// 				}

		// 				var countryCode = selectedData.Country;
		// 				var countryList = [];
		// 				for (var c = 0; c < countryCode.length; c++) {
		// 					obj = {};
		// 					obj.AttribKey = "";
		// 					obj.ParentKey = "";
		// 					obj.AttribId = "CN";
		// 					obj.AttribValue = countryCode[c];
		// 					countryList.push(obj);
		// 				}

		// 				var excludeParts = selectedData.pexcl.split(";");
		// 				var excludeList = [];
		// 				for (var e = 0; e < excludeParts.length; e++) {
		// 					obj = {};
		// 					obj.AttribKey = "";
		// 					obj.ParentKey = "";
		// 					obj.AttribId = "EX";
		// 					obj.AttribValue = excludeParts[e];
		// 					excludeList.push(obj);
		// 				}

		// 				var validParts = selectedData.pval.split(";");
		// 				var validList = [];
		// 				for (var v = 0; v < validParts.length; v++) {
		// 					obj = {};
		// 					obj.AttribKey = "";
		// 					obj.ParentKey = "";
		// 					obj.AttribId = "PV";
		// 					obj.AttribValue = validParts[e];
		// 					validList.push(obj);
		// 				}
		// 				var obj = {
		// 					"TwDays": twDays,
		// 					"Idl": selectedData.Idl ? "X" : "",
		// 					"Sts": selectedData.Sts ? "X" : "",
		// 					"Npi": selectedData.Npi ? "X" : "",
		// 					"Ipk": selectedData.Ipk ? "X" : "",
		// 					"Twe": selectedData.Twe ? "X" : "",
		// 					"Sfs": selectedData.Sfs ? "X" : "",
		// 					"Wave": wave,
		// 					"EmbargoDtTech": dateFormat.format(selectedData.EmbargoDt),
		// 					"PreOrdDtPstTech": dateFormat.format(selectedData.PreOrdDtPst),
		// 					"PreOrdDtPst": selectedData.PreOrdDtPst,
		// 					"Lob": selectedData.Lob,
		// 					"PreOrdTmPst": PreOrdTmPst,
		// 					"PreOrdTmLcl": PreOrdTmLcl,
		// 					"PreOrdDtLclTech": dateFormat.format(selectedData.PreOrdDtLcl),
		// 					"SchDateTech": dateFormat.format(selectedData.SchDate),
		// 					"SchTime": SchTime,
		// 					"Comments": selectedData.Comments,
		// 					"Status": selectedData.Status,
		// 					"ValdResult": selectedData.ValdResult,
		// 					"ValdDt": null,
		// 					"ValdTm": null,
		// 					"CreatedBy": "",
		// 					"CreatedDt": null,
		// 					"CreatedTm": null,
		// 					"ChangedBy": "",
		// 					"ChangedDt": null,
		// 					"ChangedTm": null,
		// 					"EventKey": "",
		// 					"EventId": selectedData.EventId,
		// 					"EventName": selectedData.EventName,
		// 					"LaunchDtTech": dateFormat.format(selectedData.LaunchDt),
		// 					"to_evt_prj": projList,
		// 					"to_evt_cntry": countryList,
		// 					"to_evt_pexcl": excludeList,
		// 					"to_evt_pval": validList
		// 				};

		// 				sap.ui.core.BusyIndicator.show();
		// 				this.getOwnerComponent().getModel().create("/ZCVRCI_NPI_EVENTS_HDR", obj, {
		// 					success: function (oData) {
		// 						sap.ui.core.BusyIndicator.hide();
		// 					}.bind(this),
		// 					error: function (oError) {
		// 						sap.ui.core.BusyIndicator.hide();
		// 					}
		// 				});
		// 			}
		// 		}

		// 		if (newRecordCount > 0) {
		// 			this.getOwnerComponent().getModel().submitChanges({
		// 				success: function (oData, response) {
		// 					MessageBox.success("Rows added Successfully");
		// 					that.getView().byId("idEventTable").clearSelection();
		// 					var oEditModel = that.getView().getModel("EditDataModel");
		// 					var oEditData = oEditModel.getData();
		// 					that.getView().byId("rowSave").setVisible(false);
		// 					that.getView().byId("rowCancel").setVisible(false);
		// 					that.getView().byId("rowEdit").setVisible(true);
		// 					oEditData.isFieldsEditable = false;
		// 					oEditModel.refresh(true);
		// 					that.getTableData();
		// 				},
		// 				error: function (oError) {
		// 					sap.m.MessageBox.error("Error Saving Entries!!");
		// 				}
		// 			});
		// 		} else {
		// 			MessageBox.alert("No new records added to Save");
		// 		}
		// 	}
		// },

		handleCancel: function () {
			this.getView().byId("rowSave").setVisible(false);
			this.getView().byId("rowUpdate").setVisible(false);
			this.getView().byId("rowCancel").setVisible(false);
			this.getView().byId("rowEdit").setVisible(true);
			var oEditModel = this.getView().getModel("EditDataModel");
			var oEditData = oEditModel.getData();
			oEditData.isFieldsEditable = false;
			oEditModel.refresh(true);
			var eventModel = this.getView().getModel("eventModel");
			var oEventData = eventModel.getData();

			for (var i = oEventData.length - 1; i >= 0; i--) {
				if (oEventData[i].EventId === "New") {
					oEventData.splice(i, 1);
				}
			}
			eventModel.refresh(true);
			this.getTableData();
		},

		handleBinaryData: function (str) {
			var raw = atob(str);
			var result = '';
			for (var i = 0; i < raw.length; i++) {
				var hex = raw.charCodeAt(i).toString(16);
				result += (hex.length === 2 ? hex : '0' + hex);
			}
			return result.toUpperCase();
		},

		//Function to delete selected row in table 
		handleRowDelete: function () {
			var oTable = this.getView().byId("idEventTable");
			var selectedItems = oTable.getSelectedIndices();
			var that = this,
				i;
			var oldRecord = false;
			var newRecord = false;
			var oModel = this.getView().getModel();
			var eventModel = this.getView().getModel("eventModel");
			var oEventData = eventModel.getData();
			if (selectedItems.length > 0) {
				for (i = 0; i < selectedItems.length; i++) {
					var selectedItem = oTable.getModel("eventModel").getData()[selectedItems[i]];
					if (selectedItem.EventId !== "New") {
						var binaryValue = this.handleBinaryData(oTable.getModel("eventModel").getData()[selectedItems[i]].EventKey);
						oModel.remove("/ZCVRCI_NPI_EVENTS_HDR(binary'" + binaryValue + "')", {
							method: "DELETE",
							success: function (data) {},
							error: function (e) {}
						});
						oldRecord = true;
					} else {
						newRecord = true;
					}
				}
				if (oldRecord) {
					this.getOwnerComponent().getModel().submitChanges({
						success: function (oData, response) {
							MessageBox.success("Rows deleted Successfully");
							that.getView().byId("idEventTable").clearSelection();
							var oEditModel = that.getView().getModel("EditDataModel");
							var oEditData = oEditModel.getData();
							that.getView().byId("rowSave").setVisible(false);
							that.getView().byId("rowUpdate").setVisible(false);
							that.getView().byId("rowCancel").setVisible(false);
							that.getView().byId("rowEdit").setVisible(true);
							oEditData.isFieldsEditable = false;
							oEditModel.refresh(true);
							that.getTableData();
						},
						error: function (oError) {
							sap.m.MessageBox.error("Error Saving Entries!!");
						}
					});
				}
			} else {
				MessageBox.alert("No record selected to delete");
			}
			if (newRecord) {
				for (i = oEventData.length - 1; i >= 0; i--) {
					if (oEventData[i].EventId === "New") {
						oEventData.splice(i, 1);
					}
				}
				this.getView().byId("idEventTable").clearSelection();
				eventModel.refresh(true);
			}
		},
		////Function to copy selected row in table 
		handleCopyRow: function () {
			var oTable = this.getView().byId("idEventTable");
			var selectedItems = oTable.getSelectedIndices();
			if (selectedItems.length > 0) {
				if (selectedItems.length === 1) {
					var oTableModel = this.getView().getModel("eventModel");
					var aData = oTableModel.getData();
					var selectedRecord = oTableModel.getData()[selectedItems];
					var newRecord = $.extend({}, selectedRecord);
					//	var newRecord = selectedRecord;
					newRecord.EventKey = "";
					newRecord.EventId = "New";
					aData.unshift(newRecord);
					oTableModel.setData(aData);
					oTableModel.refresh(true);
					this.getView().byId("idEventTable").clearSelection();
				} else {
					MessageBox.alert("Please select only one record to clone");
				}
			} else {
				MessageBox.alert("No record selected to clone");
			}
		},

		onPrjValueChange: function (oEvent) {
			this.projInput = oEvent.getSource();
			if (!this._prjF4HelpDialog) {
				this._prjF4HelpDialog = sap.ui.xmlfragment("prjF4Help", "com.apple.ui5.ZUI5_RDM_EVNTPL.view.fragments.prjF4Help", this);
				this.getView().addDependent(this._prjF4HelpDialog);
			}
			var existedValues = "";
			if (oEvent.getSource().getValue())
				existedValues = oEvent.getSource().getValue().split(",");
			var prjModel = this.getView().getModel("projModel");
			prjModel.setData([]);
			var data = prjModel.getData();

			for (var i = 0; i < existedValues.length; i++) {
				var object = {
					"ProjectCode": existedValues[i],
					"editable": false
				};
				data.unshift(object);
			}
			prjModel.refresh(true);
			this._prjF4HelpDialog.open();
		},

		onprjF4Cancel: function (oEvent) {
			this._prjF4HelpDialog.close();
		},
		onprjF4Close: function (oEvent) {
			var oProjModel = this.getView().getModel("projModel");
			var data = oProjModel.getData();
			var array = [];
			for (var i = 0; i < data.length; i++) {
				var value = data[i].ProjectCode;
				array.push(value);
			}
			this.projInput.setValue(array);
			this._prjF4HelpDialog.close();
		},

		addProject: function () {
			var oProjModel = this.getView().getModel("projModel");
			var aData = oProjModel.getData();
			var object;
			if (aData.length > 0) {
				if (aData[0].ProjectCode) {
					aData[0].editable = false;
					object = {
						"ProjectCode": "",
						"editable": true
					};
					aData.unshift(object);
				}
			} else {
				object = {
					"ProjectCode": "",
					"editable": true
				};
				aData.unshift(object);
			}
			oProjModel.setData(aData);
			oProjModel.refresh(true);
		},

		deleteProject: function () {
			var projTable = sap.ui.core.Fragment.byId("prjF4Help", "idprojTable");
			var oProjModel = this.getView().getModel("projModel");
			var projData = oProjModel.getData();
			var selItems = projTable.getSelectedIndices();
			if (selItems.length > 0) {
				for (var i = selItems.length - 1; i >= 0; i--) {
					var delItem = selItems[i];
					projData.splice(delItem, 1);
				}
				projTable.clearSelection();
				oProjModel.refresh(true);
			}
		},

		onValueChange: function (oEvent) {
			this.partInput = oEvent.getSource();
			var exsistedExcludeParts = oEvent.getParameter("_userInputValue");
			exsistedExcludeParts = exsistedExcludeParts.split(",");
			this.oExcludeParts = [];
			for (var i = 0; i < exsistedExcludeParts.length; i++) {
				this.oExcludeParts.push(exsistedExcludeParts[i]);
			}
			var oTable = this.getView().byId("idEventTable");
			var selRowIndex = oEvent.getSource().getParent().getIndex();
			var tableData = oTable.getModel("eventModel").getData();
			var projCode = tableData[selRowIndex].ProjectCode;
			var country = tableData[selRowIndex].Country;
			var selectedText = oEvent.getSource().getLabels()[0].getAggregation("label").getText();
			if (!this._excludeF4HelpDialog) {
				this._excludeF4HelpDialog = sap.ui.xmlfragment("excludeF4Help", "com.apple.ui5.ZUI5_RDM_EVNTPL.view.fragments.excludeF4Help", this);
				this.getView().addDependent(this._excludeF4HelpDialog);
			}
			this._excludeF4HelpDialog.setTitle(selectedText);
			this.excludePartsTable = sap.ui.core.Fragment.byId("excludeF4Help", "selectDialog");

			if (projCode && country) {
				var countryFilters = [];
				var countryArray = country;
				for (var i = 0; i < countryArray.length; i++) {
					countryFilters.push(new Filter("Country", FilterOperator.EQ, countryArray[i]));
				}
				var projFilters = [];
				var projArray = projCode.split(",");
				for (var j = 0; j < projArray.length; j++) {
					projFilters.push(new Filter("PrjCode", FilterOperator.EQ, projArray[j]));
				}
				var aFilters = [];
				aFilters.push(new sap.ui.model.Filter(countryFilters, false));
				aFilters.push(new sap.ui.model.Filter(projFilters, false));
				var that = this;
				this.oModel.read("/ZCVRCI_NPI_PARTS", {
					filters: aFilters,
					success: function (data, response) {
						var exData = data.results;
						that.excludePartsTable.setGrowingThreshold(exData.length);
						var excludeModel = new sap.ui.model.json.JSONModel();
						excludeModel.setData(exData);
						that.getView().setModel(excludeModel, "excludeModel");
						for (var l = 0; l < that.oExcludeParts.length; l++) {
							for (var n = 0; n < that.excludePartsTable.getBinding("items").oList.length; n++) {
								if (that.excludePartsTable.getBinding("items").oList[n].SkuNo === that.oExcludeParts[l]) {
									that.excludePartsTable.getItems()[n].setSelected(true);
								}
							}
						}

					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide(0);
					}
				});
			}
			this._excludeF4HelpDialog.open();
		},

		onValueExcludeSearch: function (oEvent) {
			var filters = [];
			var value = oEvent.getParameter("value");
			if (value) {
				filters = new sap.ui.model.Filter([
						new sap.ui.model.Filter("SkuNo", sap.ui.model.FilterOperator.Contains, value),
						new sap.ui.model.Filter("MatDesc", sap.ui.model.FilterOperator.Contains, value)
					],
					false);
			}
			var oTable = sap.ui.core.Fragment.byId("excludeF4Help", "selectDialog");
			oTable.getBinding("items").filter(filters, sap.ui.model.FilterType.Application);
		},

		onValueHelpDialogClose: function (oEvent) {
			var parts = [];
			var selectedItems = oEvent.getParameter("selectedItems");
			if (selectedItems && selectedItems.length) {
				for (var i = 0; i < selectedItems.length; i++) {
					parts.push(selectedItems[0].getAggregation("cells")[0].getProperty("text"));
					// parts.push(selectedItems[i].getTitle());
				}
				this.partInput.setValue(parts);
			}
		},

		onTableF4Close: function () {
			this.eventTableDialog.close();
			this.getTableData();
		},

		handleValidate: function () {
			if (!this.eventTableDialog) {
				this.eventTableDialog = sap.ui.xmlfragment("tableF4Help", "com.apple.ui5.ZUI5_RDM_EVNTPL.view.fragments.eventTable", this);
				this.getView().addDependent(this.eventTableDialog);
			}
			var oEventModel = this.getView().getModel("eventModel");
			var oEventTable = this.byId("idEventTable");
			var validationSelections = [];
			var indices = oEventTable.getSelectedIndices();
			for (var i = 0; i < oEventModel.getData().length; i++) {
				if (indices.indexOf(i) !== -1) {
					validationSelections.push({
						"EVENTID": oEventModel.getData()[i].EventId
					});
				}
			}
			validationSelections = JSON.stringify(validationSelections);
			var that = this;
			this.oModel.callFunction("/ValidateSku", {
				method: "POST",
				urlParameters: {
					EventId: validationSelections
				},
				success: function (oData, response) {
					for (var i = 0; i < oData.results.length; i++) {
						oData.results[i].ValdDate = formatter.DateFormatter(oData.results[i].ValdDate);
						oData.results[i].ValdTime = formatter.Time(oData.results[i].ValdTime.ms);

					}
					var oValidateModel = new sap.ui.model.json.JSONModel(oData.results);
					that.getView().setModel(oValidateModel, "oValidateModel");
					that.eventTableDialog.open();
				},
				error: function (oError) {
					that.eventTableDialog.close();
					var errorMesg = JSON.parse(oError.responseText).error.message.value;
					MessageBox.show(errorMesg, {
						icon: MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							if (oAction === "OK") {}
						}
					});
				}
			});

			// if (!this.eventTableDialog) {
			// 	this.eventTableDialog = sap.ui.xmlfragment("tableF4Help", "com.apple.ui5.ZUI5_RDM_EVNTPL.view.fragments.eventTable", this);
			// 	this.getView().addDependent(this.eventTableDialog);
			// }
			// this.eventTableDialog.open();
		},

		handleClear: function () {
			var oView = this.getView();
			oView.byId("country").setValue("");
			oView.byId("projCode").setValue("");
			oView.byId("eventId").setValue("");
			oView.byId("eventDesc").setValue("");
		},
		handleSearch: function (oEvent) {
			var oTable;
			var aFilters = [];
			var country = this.getView().byId("country").getValue();
			if (country.trim() !== "") {
				aFilters.push(new sap.ui.model.Filter({
					path: "Country",
					operator: "Contains",
					value1: country
				}));
			}
			var projCode = this.getView().byId("projCode").getValue();
			if (projCode.trim() !== "") {
				aFilters.push(new sap.ui.model.Filter({
					path: "ProjectCode",
					operator: "Contains",
					value1: projCode
				}));
			}
			var eventId = this.getView().byId("eventId").getValue();
			if (eventId.trim() !== "") {
				aFilters.push(new sap.ui.model.Filter({
					path: "EventId",
					operator: "EQ",
					value1: eventId
				}));
			}
			var eventDesc = this.getView().byId("eventDesc").getValue();
			if (eventDesc.trim() !== "") {
				aFilters.push(new sap.ui.model.Filter({
					path: "EventName",
					operator: "Contains",
					value1: eventDesc
				}));
			}
			oTable = this.getView().byId("idEventTable");
			oTable.getBinding("rows").filter(aFilters, sap.ui.model.FilterType.Application);
		},

		onManage: function (oEvent) {
			var aParameters = oEvent.getParameters();
			// rename variants
			if (aParameters.renamed.length > 0) {
				aParameters.renamed.forEach(function (aRenamed) {
					var sVariant = this.oVariantSet.getVariant(aRenamed.key),
						sItemValue = sVariant.getItemValue("ColumnsVal");
					// delete the variant 
					this.oVariantSet.delVariant(aRenamed.key);
					// after delete, add a new variant
					var oNewVariant = this.oVariantSet.addVariant(aRenamed.name);
					oNewVariant.setItemValue("ColumnsVal", sItemValue);
				}.bind(this));
			}
			// default variant change
			if (aParameters.def !== "*standard*") {
				this.oVariantSet.setCurrentVariantKey(aParameters.def);
			} else {
				this.oVariantSet.setCurrentVariantKey(null);
			}
			// Delete variants
			if (aParameters.deleted.length > 0) {
				aParameters.deleted.forEach(function (aDelete) {
					this.oVariantSet.delVariant(aDelete);
				}.bind(this));
			}
			//  Save the Variant Container
			this.oContainer.save().done(function () {});
		},
		onPersoButtonPressed: function () {
			this.oTablePersoController.openDialog({
				contentHeight: "28rem",
				contentWidth: "25rem",
				hasGrouping: true
			});
		},
		loadPersonalizationService: function () {
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
				var oTable = Controller.byId("idEventTable");
				var oComponent = Controller.getOwnerComponent();
				Controller.oPersService = sap.ushell.Container.getService("Personalization");
				var oPersId = {
					container: "TablePersonalization",
					item: "idEventTable"
				};
				var oScope = {
					keyCategory: Controller.oPersService.constants.keyCategory.FIXED_KEY,
					writeFrequency: Controller.oPersService.constants.writeFrequency.LOW,
					clientStorageAllowed: true
				};
				//Get Personalizer
				var oPers = Controller.oPersService.getPersonalizer(oPersId, oScope, oComponent);
				Controller.oPersService.getContainer("TablePersonalization", oScope, oComponent)
					.fail(function () {})
					.done(function (oContainer) {
						Controller.oContainer = oContainer;
						Controller.oVariantSetAdapter = new sap.ushell.services.Personalization.VariantSetAdapter(Controller.oContainer);
						//Get the variant set
						Controller.oVariantSet = Controller.oVariantSetAdapter.getVariantSet("NPIDashboardUiSet");
						if (!Controller.oVariantSet) {
							Controller.oVariantSetAdapter.addVariantSet("NPIDashboardUiSet");
							Controller.oVariantSet = Controller.oVariantSetAdapter.getVariantSet("NPIDashboardUiSet");
						}

						var variants = [];
						for (var key in Controller.oVariantSet.getVariantNamesAndKeys()) {
							var obj = {};
							obj.key = Controller.oVariantSet.getVariantNamesAndKeys()[key];
							obj.name = key;
							variants.push(obj);
						}
						Controller.variantModel = new sap.ui.model.json.JSONModel();
						Controller.variantModel.oData.Variants = variants;
						Controller.variantModel.oData.currentVariant = Controller.oVariantSet.getCurrentVariantKey();
						Controller.getView().setModel(Controller.variantModel, "variantModel");

						Controller.oTablePersoController = new TablePersoController({
							table: oTable,
							persoService: oPers
						});
					});

			}
		},
		onMassUpload: function () {

		},
		uploadChanges: function (oEvent) {
			this.byId("idFileUploadText").setValue(oEvent.getParameter("newValue"));
			this.file = oEvent.getParameters().files[0]; //oEvent.getParameter("newValue");
			this.fileName = this.file;
			this.fileType = oEvent.getParameter("files")[0].type;
		},
		handleUploadPress: function () {
			var reader = new FileReader();
			var that = this;
			reader.onload = function (e) {
				that.vContent = e.currentTarget.result;
			};
			reader.readAsDataURL(that.file);
			try {
				if (that.file) {
					this._bUploading = true;
					var serviceURL = that.oModel.sServiceUrl;
					var f = {
						headers: {
							"X-Requested-With": "XMLHttpRequest",
							"Content-Type": "multipart/mixed", //"application/atom+xml",
							"DataServiceVersion": "2.0",
							"X-CSRF-Token": "Fetch"
						},
						requestUri: serviceURL,
						method: "GET"
					};
					var oHeaders;
					var oDatamodel = that.getOwnerComponent().getModel();
					that.getView().setBusy(true);
					var name = that.byId("idFileUploadText").getValue();
					oDatamodel._request(f, function (data, oSuccess) {
						var oToken = oSuccess.headers['x-csrf-token'];
						oHeaders = {
							"X-Requested-With": "XMLHttpRequest",
							"Content-Type": "application/atom+json",
							"DataServiceVersion": "2.0",
							"x-csrf-token": oToken,
							"slug": name,
						};
						var oURL = serviceURL + "/FileUploadSet";
						oDatamodel.attachRequestFailed(function (oEvent) {
							var data = oEvent;
						});
						jQuery.ajax({
							type: 'POST',
							dataType: "json",
							url: oURL,
							headers: oHeaders,
							cache: false,
							contentType: that.file.type,
							processData: false,
							data: that.file,
							success: function (data, oResponse) {
								that.getView().setBusy(false);
								that.byId("idFileUploadText").setValue();
								var errors = [];
								if (data.d.ErrorCount !== 0) {
									for (var i = 0; i < data.d.ErrorCount; i++) {
										errors.push({
											"TotalCount": data.d.TotalCount,
											"SuccessCount": data.d.SuccessCount,
											"ErrorCount": data.d.ErrorCount,
											"LINE_NO": JSON.parse(data.d.ErrorLog)[i].LINE_NO,
											"MESSAGE": JSON.parse(data.d.ErrorLog)[i].ERR_MSGS[0].MESSAGE
										});

									}
									var errorModel = new sap.ui.model.json.JSONModel(errors);
									that.getView().setModel(errorModel, "errorModel");
								}
								if (!that.errorDialog) {
									that.errorDialog = sap.ui.xmlfragment("errorLog", "com.apple.ui5.ZUI5_RDM_EVNTPL.view.fragments.errorLog", that);
									that.getView().addDependent(that.errorDialog);
								}
								that.errorDialog.open();
								// else if (data.d.SuccessCount !== 0) {
								// 	MessageBox.success("Record(s) Saved!");

								// }

							},
							error: function (data, oResponse) {
								that.getView().setBusy(false);
								if (data.responseText) {
									var message = JSON.parse(data.responseText).error.message.value;
									MessageBox.error(message);
								}
							}
						});

					});

				}

			} catch (oException) {
				sap.ui.core.BusyIndicator.hide();
			}
		},
		handleErrorClose: function () {
			this.errorDialog.close();
		},
		handleValidatedResultDialog: function (oEvent) {
			// ZC_RCI_VALDRESULTS?$format=json&$filter= EventId eq ‘1000000106'
			if (!this.eventTableDialog) {
				this.eventTableDialog = sap.ui.xmlfragment("tableF4Help", "com.apple.ui5.ZUI5_RDM_EVNTPL.view.fragments.eventTable", this);
				this.getView().addDependent(this.eventTableDialog);
			}
			// var oEventModel = this.getView().getModel("eventModel");
			// var oEventTable = this.byId("idEventTable");

			var aFilters = [];
			var selEventId = oEvent.getSource().getBindingContext("eventModel").getProperty("EventId");
			aFilters.push(new Filter("EventId", FilterOperator.EQ, selEventId));

			var that = this;
			this.oModel.read("/ZC_RCI_VALDRESULTS", {
				filters: aFilters,
				success: function (oData) {
					for (var i = 0; i < oData.results.length; i++) {
						oData.results[i].ValdDate = formatter.DateFormatter(oData.results[i].ValdDate);
						oData.results[i].ValdTime = formatter.Time(oData.results[i].ValdTime.ms);

					}
					var oValidateModel = new sap.ui.model.json.JSONModel(oData.results);
					that.getView().setModel(oValidateModel, "oValidateModel");
					that.eventTableDialog.open();
				},
				error: function (oError) {
					that.eventTableDialog.close();
					var errorMesg = JSON.parse(oError.responseText).error.message.value;
					MessageBox.show(errorMesg, {
						icon: MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							if (oAction === "OK") {}
						}
					});
				}
			});

			// if (!this.eventTableDialog) {
			// 	this.eventTableDialog = sap.ui.xmlfragment("tableF4Help", "com.apple.ui5.ZUI5_RDM_EVNTPL.view.fragments.eventTable", this);
			// 	this.getView().addDependent(this.eventTableDialog);
			// }
			// this.eventTableDialog.open();

			// var that = this;
			// this.oModel.callFunction("/ZC_RCI_VALDRESULTS", {
			// 	method: "POST",
			// 	urlParameters: {
			// 		EventId: validationSelections
			// 	},
			// 	success: function (oData, response) {
			// 		for (var i = 0; i < oData.results.length; i++) {
			// 			oData.results[i].ValdDate = formatter.DateFormatter(oData.results[i].ValdDate);
			// 			oData.results[i].ValdTime = formatter.Time(oData.results[i].ValdTime.ms);

			// 		}
			// 		var oValidateModel = new sap.ui.model.json.JSONModel(oData.results);
			// 		that.getView().setModel(oValidateModel, "oValidateModel");
			// 		that.eventTableDialog.open();
			// 	},
			// 	error: function (oError) {
			// 		that.eventTableDialog.close();
			// 		var errorMesg = JSON.parse(oError.responseText).error.message.value;
			// 		MessageBox.show(errorMesg, {
			// 			icon: MessageBox.Icon.ERROR,
			// 			title: "Error",
			// 			actions: [sap.m.MessageBox.Action.OK],
			// 			onClose: function (oAction) {
			// 				if (oAction === "OK") {}
			// 			}
			// 		});
			// 	}
			// });

		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.apple.ui5.ZUI5_RDM_EVNTPL.view.NPIPlanning
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.apple.ui5.ZUI5_RDM_EVNTPL.view.NPIPlanning
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.apple.ui5.ZUI5_RDM_EVNTPL.view.NPIPlanning
		 */
		//	onExit: function() {
		//
		//	}
	});
});