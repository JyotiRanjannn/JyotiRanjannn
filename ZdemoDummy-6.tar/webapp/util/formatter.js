sap.ui.define([], function () {
	"use strict";
	return {
		DateFormatter: function (oValue) {
			if (oValue !== null && oValue !== undefined && oValue !== "") {
				var oDate = new Date(oValue); //Sunil: passing the date value that comes from back-end as an argument to the Date constructor
				var year = oDate.getFullYear().toString();
				var month = (oDate.getMonth() + 1).toString();
				if (month < 10) {
					month = "0" + month;
				}
				var date = oDate.getDate().toString();
				if (date < 10) {
					date = "0" + date;
				}
				var oFinalDate = month + "/" + date + "/" + year;
				return oFinalDate;
			}
		},

		TimeFormatter: function (oValue) {
			var value = oValue;
		},
		image: function (flag) {
			var oModulePath = jQuery.sap.getModulePath("com.apple.ui5.ZUI5_RDM_EVNTPL");
			if (flag === "X") {
				return oModulePath + "/images/tick.png";
			} else {
				return oModulePath + "/images/wrong.png";
			}

		},
		Time: function (val) {
			if (val) {
				var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "HH:mm:ss"
				});
				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				return timeFormat.format(new Date(val + TZOffsetMs));
			}
			return null;
		},
		SuccessMessage : function(sFlag){
			var i18n = this.i18n.aPropertyFiles[0];
			if(sFlag === "S"){
				return i18n.getProperty("Success_msg");
			}else if(sFlag === "F"){
					return i18n.getProperty("Fail_msg");
			}else {
				return "";
			}
		},

		statusFormatter: function (oValue) {
			if (oValue) {
				if (oValue === "E") {
					return "Execute";
				} else if (oValue === "C") {
					return "Closed";
				} else if (oValue === "P") {
					return "Plan";
				} else {
					return "Review";
				}
			}
		}

	};
});